jQuery(document).ready(function($) {
    // ======= مدیریت نمایش فیلدهای API ======= //
    function toggleServiceFields() {
        // مخفی کردن تمام فیلدهای سرویس
        $('.iur-service-field').hide();
        
        // دریافت سرویس انتخاب شده
        const service = $('#iur-upload-method').val();

        // نمایش فیلد مربوط به سرویس انتخاب شده
        switch(service) {
            case 'freeimage':
                $('#tr_freeimage_api_key').show();
                break;
            case 'imgbb':
                $('#tr_imgbb_api_key').show();
                break;
            case 'cloudinary':
                $('#tr_cloudinary_api_key, #tr_cloudinary_api_secret, #tr_cloudinary_cloud_name').show();
                break;
            // حالت پیش‌فرض برای 'wordpress' نیاز به اقدام ندارد
        }
    }
    
    function toggleApiFields() {
                $('.iur-api-field, .iur-service-field').hide();
                const service = $('#iur_upload_method').val();
                
                if (service === 'freeimage') {
                    $('#tr_freeimage_api_key').show();
                } else if (service === 'imgbb') {
                    $('#tr_imgbb_api_key').show();
                } else if (service === 'cloudinary') {
                    $('#tr_cloudinary_api_key, #tr_cloudinary_api_secret, #tr_cloudinary_cloud_name').show();
                }
            }
            
            $('#iur_upload_method').change(toggleApiFields);
            toggleApiFields(); // Initialize on load
        });

    // اجرای اولیه و رویداد تغییر
    toggleServiceFields();
    $('#iur-upload-method').on('change', toggleServiceFields);

    // ======= پاکسازی خطاها ======= //
    $('#iur-clear-errors').on('click', function(e) {
        e.preventDefault();
        
        if (!confirm('آیا مطمئن هستید می‌خواهید تمام خطاها را پاک کنید؟')) return;
        
        const $button = $(this);
        const originalText = $button.text();
        $button.prop('disabled', true).text('در حال پاکسازی...');
        
        $.post(iur_vars.ajaxurl, {
            action: 'iur_clear_errors',
            security: iur_vars.nonce
        }).done(function(response) {
            if (response?.success) {
                $('#iur-error-log').html('<p class="notice notice-success">خطاها با موفقیت پاک شدند</p>');
            } else {
                alert('خطا: ' + (response?.data?.message || 'پاسخ نامعتبر از سرور'));
            }
        }).always(() => {
            $button.prop('disabled', false).text(originalText);
        });
    });

    // ======= نمایش/پنهان کردن تنظیمات پیشرفته ======= //
    $('.iur-toggle-advanced').on('click', function(e) {
        e.preventDefault();
        $('.iur-advanced-settings').stop(true, true).slideToggle();
    });
    
    // ======= پردازش تکی پست‌ها ======= //
$('.iur-process-post').on('click', function(e) {
    e.preventDefault();
    
    const $button = $(this);
    const post_id = $button.data('postid');
    const originalText = $button.text();
    
    $button.prop('disabled', true).text('در حال پردازش...');
    
    $.post(iur_vars.ajaxurl, {
        action: 'iur_process_single_post',
        security: iur_vars.nonce,
        post_id: post_id
    }).done(function(response) {
        if (response.success) {
            alert('پست با موفقیت پردازش شد! تصاویر جایگزین شده: ' + response.data.replaced);
            // به‌روزرسانی UI
            location.reload();
        } else {
            alert('خطا: ' + response.data.message);
        }
    }).fail(function() {
        alert('خطا در ارتباط با سرور');
    }).always(() => {
        $button.prop('disabled', false).text(originalText);
    });
});
    
    // تغییر به:
function iur_update_progress(percent) {
    $('#iur-progress-bar').css('width', percent + '%');
    $('#iur-progress-label').text(percent + '%');
}

$('#iur_bulk_process').on('click', function() {
  const $btn    = $(this);
  const $status = $('#iur_bulk_process_status');
  const $bar    = $('#iur_progress_bar');
  const $fill   = $('#iur_progress_bar_fill');
  const $text   = $('#iur_progress_text');

  $btn.prop('disabled', true);
  $status.html('<span class="spinner is-active"></span> Processing...');
  $bar.show();

  let processed = 0, total = 0;

  function processBatch(offset = 0) {
    $.ajax({
      url: iur_vars.ajax_url,
      type: 'POST',
      timeout: parseInt(iur_vars.timeout) * 1000, // تبدیل به میلی‌ثانیه
      data: {
        action: 'iur_bulk_process',
        offset: offset,
        _wpnonce: iur_vars.nonce
      },
      success: function(response) {
        if (response.success) {
          processed += response.data.processed;
          total      = response.data.total;
          const pct  = Math.round((processed / total) * 100);

          $fill.css('width', pct + '%');
          $text.text(`${processed} / ${total} (${pct}%)`);

          if (response.data.completed) {
            $status.html('<span style="color:#28a745;">✓ Bulk processing completed successfully!</span>');
            $btn.prop('disabled', false);
          } else {
            processBatch(offset + parseInt(iur_vars.limit));
          }
        } else {
          $status.html(`<span style="color:#dc3545;">✗ ${response.data.message}</span>`);
          $btn.prop('disabled', false);
        }
      },
      error: function(_, textStatus) {
        if (textStatus === 'timeout') {
          $status.html('<span style="color:#dc3545;">⏱️ Request timed out. Try increasing the timeout value.</span>');
        } else {
          $status.html('<span style="color:#dc3545;">✗ Server error occurred.</span>');
        }
        $btn.prop('disabled', false);
        $bar.hide();
      }
    });
  }

  processBatch();
});

});