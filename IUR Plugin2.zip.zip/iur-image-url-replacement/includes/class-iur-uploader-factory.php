<?php
class IUR_Uploader_Factory {
    public static function create($service, $settings) {
        switch ($service) {
            case 'freeimage':
                return new IUR_FreeImage_Uploader($settings['freeimage_api_key']);
            case 'imgbb':
                return new IUR_ImgBB_Uploader($settings['imgbb_api_key']);
            case 'cloudinary':
                return new IUR_Cloudinary_Uploader([
                    'api_key' => $settings['cloudinary_api_key'],
                    'api_secret' => $settings['cloudinary_api_secret'],
                    'cloud_name' => $settings['cloudinary_cloud_name']
                ]);
            case 'wordpress':
                return new IUR_WP_Media_Uploader();
            default:
                throw new Exception("Unsupported service: $service");
        }
    }
}