<?php
// includes/class-iur-uploader.php
class IUR_Uploader {
    private $upload_service;
    private $error_handler;
    
    public function __construct() {
        $this->error_handler = IUR_Error_Handler::get_instance();
        $this->init_upload_service();
    }
    
    public static function get_instance() {
    static $instance = null;

    if ($instance === null) {
        $instance = new self();
    }

    return $instance;
}

   public function get_method() {
    $settings = IUR_Settings::get_instance();
    return $settings->get('upload_method');
}
    
    private function init_upload_service() {
        $settings = IUR_Settings::get_instance();
        $method = $settings->get('upload_method');
        $quality = $settings->get('quality');
        
        switch ($method) {
            case 'imgbb':
                $this->upload_service = new IUR_ImgBB_Service(
                    $settings->get_api_key('imgbb'),
                    $quality
                );
                break;
                
            case 'cloudinary':
    $cloudinary_config = $settings->get_api_key('cloudinary');
    // دیباگ: چاپ تنظیمات Cloudinary
    error_log('Cloudinary Config: ' . print_r($cloudinary_config, true));
    $this->upload_service = new IUR_Cloudinary_Service([
        'api_key' => $cloudinary_config['api_key'],
        'api_secret' => $cloudinary_config['api_secret'],
        'cloud_name' => $cloudinary_config['cloud_name'],
        'folder' => $cloudinary_config['folder'], // اضافه کردن folder
        'secure' => $cloudinary_config['secure'], // اضافه کردن secure
        'quality' => $quality
    ]);
    break;
                
            case 'wordpress':
                $this->upload_service = new IUR_WP_Media_Service();
                break;
                
            default:
                $this->upload_service = new IUR_FreeImage_Service(
                    $settings->get_api_key('freeimage'),
                    $quality
                );
        }
    }
    
    public function upload_images(array $image_urls, $post_id = 0) {
    $results = [];
    foreach ($image_urls as $url) {
        try {
            $results[] = [
                'success' => true,
                'url' => $this->upload_image($url, $post_id),
                'original' => $url
            ];
        } catch (Exception $e) {
            $results[] = [
                'success' => false,
                'error' => $e->getMessage(),
                'original' => $url
            ];
            $this->error_handler->log($e->getMessage(), 'upload', [
                'post_id' => $post_id,
                'image_url' => $url
            ]);
        }
    }
    return $results;
}

private function encrypt_data($data, $key) {
    $iv = openssl_random_pseudo_bytes(16);
    return openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);
}
    
    private function download_image($url, $timeout = 60) {
    $args = ['timeout' => $timeout];
    $response = wp_remote_get($url, $args);
    if (is_wp_error($response)) {
        throw new Exception('Download failed: ' . $response->get_error_message());
    }
    return wp_remote_retrieve_body($response);
}

    public function upload_image($image_url, $post_id = 0, $max_retries = 3) {
    // اعتبارسنجی اولیه
    if (empty($image_url) || !filter_var($image_url, FILTER_VALIDATE_URL)) {
        throw new InvalidArgumentException('Invalid image URL.');
    }

    $retry_count = 0;

    while ($retry_count < $max_retries) {
        try {
            $image_data = $this->download_image($image_url);
            return $this->upload_service->upload($image_data, $post_id);
        } catch (Exception $e) {
            $retry_count++;
            if ($retry_count === $max_retries) {
if (method_exists($this->error_handler, 'log')) {
    $this->error_handler->log($e->getMessage(), 'upload', [
        'post_id' => $post_id,
        'image_url' => $image_url
    ]);
} else {
    error_log('IUR Upload Error: ' . $e->getMessage());
}
                throw $e;
            }
            sleep(1); // تأخیر قبل از تلاش مجدد
        }
    }
}
}