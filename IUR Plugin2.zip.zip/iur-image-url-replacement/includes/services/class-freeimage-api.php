<?php
class FreeImage_API {
    const API_ENDPOINT = 'https://freeimage.host/api/1/upload';
    const MAX_RETRIES = 3;
    const TIMEOUT = 30;
    
    private $api_key;
    private $quality;
    private $error_handler;
    
    public function __construct($api_key, $quality = 'high') {
        $this->api_key = sanitize_text_field($api_key);
        $this->quality = in_array($quality, ['low', 'medium', 'high']) ? $quality : 'high';
        $this->error_handler = IUR_Error_Handler::get_instance();
    }
    
    /**
     * آپلود تصویر با مدیریت پیشرفته خطاها
     */
    public function upload_image($image_data, $image_type) {
        // اعتبارسنجی اولیه
        if (empty($this->api_key)) {
            return $this->log_and_return_error('missing_api_key', 'API key is required');
        }
        
        if (empty($image_data)) {
            return $this->log_and_return_error('empty_image', 'Image data cannot be empty');
        }
        
        // آماده‌سازی داده‌ها
        try {
            $prepared_data = $this->prepare_image_data($image_data, $image_type);
        } catch (Exception $e) {
            return $this->log_and_return_error('image_preparation', $e->getMessage());
        }
        
        // اجرای درخواست با قابلیت retry
        $retry_count = 0;
        do {
            $response = $this->make_api_request($prepared_data);
            
            if (!is_wp_error($response)) {
                return $this->process_successful_response($response);
            }
            
            $retry_count++;
            if ($retry_count < self::MAX_RETRIES) {
                sleep(1); // تاخیر بین تلاش‌ها
            }
        } while ($retry_count < self::MAX_RETRIES);
        
        return $response; // آخرین خطا
    }
    
    /**
     * آماده‌سازی داده‌های تصویر
     */
    private function prepare_image_data($image_data, $image_type) {
        // اعتبارسنجی نوع تصویر
        $valid_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($image_type, $valid_types)) {
            throw new Exception("Invalid image type: {$image_type}");
        }
        
        // محدودیت حجم فایل (2MB)
        if (strlen($image_data) > 2 * 1024 * 1024) {
            throw new Exception("Image size exceeds 2MB limit");
        }
        
        return [
            'key' => $this->api_key,
            'source' => base64_encode($image_data),
            'format' => 'json',
            'action' => 'upload',
            'type' => 'file',
            'quality' => $this->quality
        ];
    }
    
    /**
     * ارسال درخواست به API
     */
    private function make_api_request($data) {
        $args = [
            'body' => $data,
            'timeout' => self::TIMEOUT,
            'headers' => [
                'Accept' => 'application/json',
                'X-IUR-Version' => IUR_VERSION // اضافه کردن هدر سفارشی
            ]
        ];
        
        $response = wp_remote_post(self::API_ENDPOINT, $args);
        
        if (is_wp_error($response)) {
            $this->error_handler->log(
                'HTTP Error: ' . $response->get_error_message(),
                'freeimage_api',
                $data
            );
            return $response;
        }
        
        return $response;
    }
    
    /**
     * پردازش پاسخ موفق API
     */
    private function process_successful_response($response) {
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // لاگ پاسخ برای دیباگ
        $this->error_handler->log_api_response($data, 'freeimage');
        
        // بررسی خطاهای API
        if ($response_code !== 200) {
            $error_msg = $data['error']['message'] ?? 'Unknown API error';
            return $this->log_and_return_error(
                'api_error', 
                "HTTP {$response_code}: {$error_msg}",
                $data
            );
        }
        
        // استخراج URL از ساختارهای مختلف پاسخ
        $url = $this->extract_image_url($data);
        
        if (empty($url)) {
            return $this->log_and_return_error(
                'invalid_response',
                'No image URL found in API response',
                $data
            );
        }
        
        return esc_url_raw($url); // پاکسازی URL خروجی
    }
    
    /**
     * استخراج URL تصویر از پاسخ
     */
    private function extract_image_url($api_data) {
        $url_paths = [
            'image.url',
            'image.display_url',
            'image.medium.url',
            'image.thumb.url'
        ];
        
        foreach ($url_paths as $path) {
            $value = $this->array_get($api_data, $path);
            if (!empty($value)) {
                return $value;
            }
        }
        
        return null;
    }
    
    /**
     * دسترسی ایمن به آرایه با مسیر نقطه‌دار
     */
    private function array_get($array, $path, $default = null) {
        $keys = explode('.', $path);
        foreach ($keys as $key) {
            if (!isset($array[$key])) {
                return $default;
            }
            $array = $array[$key];
        }
        return $array;
    }
    
    /**
     * ثبت خطا و بازگشت WP_Error
     */
    private function log_and_return_error($code, $message, $context = []) {
        $this->error_handler->log($message, 'freeimage_api', $context);
        return new WP_Error($code, $message, $context);
    }
}