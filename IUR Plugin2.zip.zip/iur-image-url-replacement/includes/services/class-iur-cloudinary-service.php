<?php
class IUR_Cloudinary_Service implements IUR_Upload_Interface {
    private $config;
    private $cloudinary;
    private $timeout;
    
    public function get_method_name() {
        return 'cloudinary';
    }

    public function __construct($config, $timeout= 30) {
        // بررسی وجود SDK
        if (!class_exists('Cloudinary\Cloudinary')) {
            throw new Exception('Cloudinary SDK not loaded. Run composer install.');
        }
        
        $this->config = wp_parse_args($config, [
            'cloud_name' => '',
            'api_key' => '',
            'api_secret' => '',
            'folder' => 'iur_uploads',
            'secure' => true
        ]);
        
        $this->timeout = $timeout;
        
        // Do not validate credentials here, we'll validate when uploading
        // Only initialize the Cloudinary object if we have credentials?
        // We cannot initialize without credentials, so we leave it until upload
    }

    private function initialize_cloudinary() {
        // Moved initialization to upload method after validation
        $this->cloudinary = new \Cloudinary\Cloudinary([
            'cloud' => [
                'cloud_name' => $this->config['cloud_name'],
                'api_key'    => $this->config['api_key'],
                'api_secret' => $this->config['api_secret'],
            ],
            'url' => [
                'secure' => $this->config['secure']
            ]
        ]);
    }

    public function upload($image_data, $post_id = 0) {
        $this->validate_credentials(); // Now validate when uploading
        
        try {
            if (!isset($this->cloudinary)) {
                $this->initialize_cloudinary();
            }
            
            $temp_file = $this->create_temp_file($image_data);
            
            $result = $this->cloudinary->uploadApi()->upload($temp_file, [
            'folder' => $this->config['folder'],
            'public_id' => 'post_' . $post_id . '_' . time(),
            'overwrite' => false
        ]);
            
            @unlink($temp_file);
            return $result['secure_url'];
        } catch (\Exception $e) {
            if (isset($temp_file)) @unlink($temp_file);
            error_log('Cloudinary Error: ' . $e->getMessage());
            throw new Exception('Cloudinary Error: ' . $e->getMessage());
        }
    }

    private function create_temp_file($data) {
        $temp_path = wp_tempnam() . '.jpg';
        if (file_put_contents($temp_path, $data) === false) {
        throw new Exception('Failed to write temporary file');
    }
    return $temp_path;
}

    public function validate_credentials() {
        if (empty($this->config['cloud_name']) || 
            empty($this->config['api_key']) || 
            empty($this->config['api_secret'])) {
            throw new Exception('Cloudinary credentials incomplete');
        }
    }
}