<?php
class IUR_Ajax_Handler {
    public static function init() {
        add_action('wp_ajax_iur_test_api_connection', [__CLASS__, 'handle_test_connection']);
    }

    public static function handle_test_connection() {
        check_ajax_referer('iur_test_api_nonce', '_wpnonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Unauthorized', 'iur')], 403);
        }
        
        $service = $_POST['service'] ?? '';
        $settings = get_option('iur_settings', []);
        
        // پاسخ تستی موقت
        $services = ['freeimage', 'imgbb', 'cloudinary', 'wordpress'];
        
        if (in_array($service, $services)) {
            wp_send_json_success([
                'message' => __('Connection test successful!', 'iur')
            ]);
        } else {
            wp_send_json_error([
                'message' => __('Invalid service selected', 'iur')
            ]);
        }
    }
}

IUR_Ajax_Handler::init();