<?php
class IUR_Bulk_Processor {
    private static $instance = null;
    private $processor;
    private $settings;

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->processor = IUR_Processor::init();
        $this->settings = IUR_Settings::get_instance();
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action('admin_action_iur_bulk_process', [$this, 'handle_bulk_action']);
        add_filter('bulk_actions-edit-post', [$this, 'register_bulk_actions']);
        add_filter('bulk_actions-edit-product', [$this, 'register_bulk_actions']);
        add_action('admin_notices', [$this, 'bulk_admin_notices']);
    }

    public function register_bulk_actions($bulk_actions) {
        $bulk_actions['iur_bulk_process'] = __('Process Images with IUR', 'iur');
        return $bulk_actions;
    }

    public function handle_bulk_action() {
        if (empty($_REQUEST['post']) || !is_array($_REQUEST['post'])) {
            return;
        }

        check_admin_referer('bulk-posts');

        $post_ids = array_map('intval', $_REQUEST['post']);
        $results = [
            'success' => 0,
            'failed' => 0,
            'skipped' => 0
        ];
        
        $max_execution_time = ini_get('max_execution_time');
    if ($max_execution_time > 0 && $max_execution_time < 300) {
        @set_time_limit(300); // 5 دقیقه
    }

        foreach ($post_ids as $post_id) {
        try {
            $result = $this->processor->process_post($post_id);
            if (!empty($result['replaced'])) {
                $results['success']++;
            } else {
                $results['skipped']++;
            }
        } catch (Exception $e) {
            $results['failed']++;
            error_log('IUR Bulk Process Error for post ' . $post_id . ': ' . $e->getMessage());
        }

        // آزادسازی حافظه بعد از هر پست
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        if (function_exists('gc_collect_cycles')) {
            gc_collect_cycles();
        }
    }

    // بازگرداندن زمان اجرا به مقدار قبلی
    if (isset($max_execution_time)) {
        @set_time_limit($max_execution_time);
    }

    set_transient('iur_bulk_process_results', $results, 60);
    wp_redirect(wp_get_referer());
    exit;
}

    public function bulk_admin_notices() {
        if (!empty($_REQUEST['iur_bulk_action'])) {
            $results = get_transient('iur_bulk_process_results');
            if (false === $results) {
                return;
            }

            $message = sprintf(
                __('Processed %d posts: %d success, %d skipped, %d failed.', 'iur'),
                array_sum($results),
                $results['success'],
                $results['skipped'],
                $results['failed']
            );

            echo '<div class="notice notice-info is-dismissible"><p>' . esc_html($message) . '</p></div>';
            delete_transient('iur_bulk_process_results');
        }
    }

    public static function get_instance() {
        return self::$instance;
    }
}