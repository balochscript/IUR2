<?php
class IUR_Error_Handler {
    public function __construct() {
        add_action('admin_notices', [$this, 'display_errors']);
    }
    
    /**
 * Initialize the error handler by registering necessary hooks
 * and preparing the log environment.
 */
/**
 * Static initializer for error handler.
 * Registers hooks and prepares logging environment.
 */
public static function init() {
    $instance = new self();

    // فقط در بخش مدیریت وردپرس فعال شود
    if (is_admin()) {
        add_action('admin_notices', [$instance, 'display_errors']);
    }

    // تعریف مسیر دقیق فایل لاگ
    if (!defined('IUR_LOG_PATH')) {
        define('IUR_LOG_PATH', plugin_dir_path(dirname(__FILE__)) . 'logs/error.log');
    }

    $log_file = IUR_LOG_PATH;
    $log_dir = dirname($log_file);

    // بررسی و ساخت پوشه لاگ در صورت نبود
    if (!is_dir($log_dir)) {
        // استفاده از mkdir به جای wp_mkdir_p در محیط‌هایی مثل اندروید
        if (!mkdir($log_dir, 0755, true)) {
            error_log('[IUR] خطا در ساخت پوشه لاگ: ' . $log_dir);
            return;
        }
    }

    // اگر فایل لاگ وجود نداره، ایجادش با بررسی مجوزها
    if (!file_exists($log_file)) {
        if (is_writable($log_dir)) {
            @file_put_contents($log_file, "=== شروع گزارش خطاهای افزونه IUR ===\n");
        } else {
            error_log('[IUR] پوشه logs قابل نوشتن نیست: ' . $log_dir);
            return;
        }
    }

    // بررسی نهایی نوشتن در فایل لاگ
    if (!is_writable($log_file)) {
        error_log('[IUR] فایل لاگ قابل نوشتن نیست: ' . $log_file);
    }
}

public function log($message, $type = 'general', $context = []) {
    $log_entry = [
        'timestamp' => current_time('mysql'),
        'type' => $type,
        'message' => $message,
        'context' => $context
    ];
    
    // ذخیره در آپشن وردپرس
    $logs = get_option('iur_error_logs', []);
    $logs[] = $log_entry;
    update_option('iur_error_logs', $logs);
    
    // همچنین در فایل لاگ بنویسید
    if (defined('IUR_LOG_FILE')) {
        error_log(print_r($log_entry, true), 3, IUR_LOG_FILE);
    }
}

public static function get_instance() {
    static $instance = null;

    if ($instance === null) {
        $instance = new self();
    }

    return $instance;
}

    public function display_errors() {
        global $post;
        
        if (!$post || !is_admin()) {
            return;
        }
        
        $errors = get_post_meta($post->ID, '_iur_errors', true);
        
        if (!empty($errors) && is_array($errors)) {
    echo '<div class="notice notice-error"><p><strong>خطاهای جایگزینی تصاویر:</strong></p><ul>';
    foreach ($errors as $error) {
        echo '<li>' . esc_html($error) . '</li>';
    }
    echo '</ul></div>';
    delete_post_meta($post->ID, '_iur_errors');
}
    }
}